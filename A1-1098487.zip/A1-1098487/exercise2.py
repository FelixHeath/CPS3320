
#exercise 2 wangzhitao 1098487

#input the systolic value
systolic_value = input("Please input your systolic value: ")
s = int(systolic_value)

while s <= 0:
    print("the input must be wrong.")
    s = int(input("Please enter a positive integer: "))

if s >= 180:
    print("The Systolic value", s, "implies a Hypersensitive crisis blood pressure case.")
elif 160 <= s < 180:
    print("The Systolic value", s, "implies a High blood stage 2 blood pressure case.")
elif 140 <= s < 160:
    print("The Systolic value", s, "implies a High blood stage 1 blood pressure case.")
elif 120 <= s < 140:
    print("The Systolic value", s, "implies a Prehypertension blood pressure case.")
else:
    print("The Systolic value", s, "implies a Normal blood pressure case.")



