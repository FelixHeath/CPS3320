
#exercise 1 wangzhitao 1098487
n = 1; #used to set a judge to check whether the inputs are correct
while n==1:
    numberlist =[]
    for  x  in range(12): # create list with range 12
        numberlist.append( float(input("numbers please: ")))
    print (numberlist[:])

    # compare with the correct list
    numberlist2=[6,1,1,3,1,5,6,2,16,8,2,11]
    if numberlist != numberlist2:
        print("number has been inputed wrondly please check once again")

        # correct input set n=0, move to the result calculation
    else: print("correct input"); n = 0

cal1 = numberlist[2]/numberlist[3]
cal2 = numberlist[4]/numberlist[5]
cal3 = numberlist[6]/numberlist[7]
cal4 = numberlist[8]/numberlist[9]
cal5 = numberlist[10]/numberlist[11]
cal6 = numberlist[1]-cal1-cal2+cal3+cal4-cal5
result = numberlist[0]*cal6
print("The result of solving the expression: "
      "6.0 * (1 - (1/3) - (1.0/5) + (6.0/2.0) "
      "+ (16/8) - (2.0/11)) is:", result)


