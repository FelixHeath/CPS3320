
#1098487 wangzhitao assignment2

#import the required packages
import requests
from bs4 import BeautifulSoup

# first to build a class for data storing
class Country:

    # build a constructor for class country
    # five dimensions for the items
    def __init__(self, country, gdp_imf, gdp_un, gdp_capita, population):
        self.country = country
        self.gdp_imf = gdp_imf
        self.gdp_un = gdp_un
        self.gdp_capita = gdp_capita
        self.population = population

    #string output with ***** to divide each item
    def get_string(self):
        return "country: " + str(self.country) + "\n" \
               + "gdp_imf: " + str(self.gdp_imf) + "\n" \
               + "gdp_un: " + str(self.gdp_un) + "\n" \
               + "gdp_capita: " + str(self.gdp_capita) + "\n" \
               + "population: " + str(self.population) + "\n" \
               + "*" * 50 + "\n"

# This function performs the scrape of pages and assigns each piece of information to a corresponding variable.
def req_info():
    gdp_rank = []
    url = "https://worldpopulationreview.com/countries/countries-by-gdp"

    #use requests to get html file from the url
    response = requests.get(url)

    #decode the file content to utf-8
    content = response.content.decode('utf8')

    #create tag to find the data we want from the content
    tag = BeautifulSoup(content, "html.parser")

    #convert the table nad find information we want
    table = tag.find_all('table', class_='jsx-130793 table table-striped tp-table-body')
    trs = table[0].find('tbody').find_all('tr')
    for tr in trs:
        country = tr.contents[1].a.string
        gdp_imf = tr.contents[2].string
        gdp_un = tr.contents[3].string
        gdp_capita = tr.contents[4].string
        population = tr.contents[5].string
        gdp_rank.append(Country(country, gdp_imf, gdp_un, gdp_capita, population))

    return gdp_rank

# This function calls get_string method to create strings out of each country's attributes.
def format_store(gdp_rank):
    with open("World_GDP_Ranking.txt", "a", encoding='utf-8') as f:
        for gdprank in gdp_rank:
            each_gr = gdprank.get_string()
            f.write(each_gr)

# This function performs a frequency count of all words in the txt file using the dictionary concept.
def word_freq():
    with open("World_GDP_Ranking.txt", "r") as f:
        content = f.read().replace('\n', '; ').split('**************************************************')
        gdp_rank = {}
        rank = 1
        for gdprank in content:
            gdp_rank['#'+str(rank)] = gdprank
            rank += 1

        print(gdp_rank)


def main():
    gdp_rank = req_info()
    format_store(gdp_rank)
    word_freq()


if __name__ == '__main__':
    main()
